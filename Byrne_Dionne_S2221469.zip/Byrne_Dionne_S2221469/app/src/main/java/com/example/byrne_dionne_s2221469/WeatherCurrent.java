
//
// Name                 Dionne Jayne Byrne
// Student ID           s2221469
// Programme of Study   Bsc (Hons) Computing
//

package com.example.byrne_dionne_s2221469;

public class WeatherCurrent {
    private String title;
    private String link;
    private String description;
    private String pubdate;
    private int temp;
    private String classification;
    private String daytime;

    public WeatherCurrent() {
        title = "";
        link = "";
        description = "";
        pubdate = "";
        temp = 0;
        classification = "";
        daytime = "";
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;

        //parse daytime, temp and classification
        //Wednesday - 23:00 BST: Not available, 6°C (42°F)

        try {
            String dt = title.substring(0, title.indexOf(':', title.indexOf("-") + 6));
            this.daytime = dt;

            String clsfn = title.substring(title.indexOf(':', title.indexOf("-") + 6) + 1, title.indexOf(',')).trim();
            this.classification = clsfn;

            String tmp = title.substring(title.indexOf(',') + 1, title.indexOf('°')).trim();
            this.temp = Integer.parseInt(tmp);

        } catch (Exception e) {

        }

    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPubdate() {
        return pubdate;
    }

    public void setPubdate(String pubdate) {
        this.pubdate = pubdate;
    }

    public int getTemp() {
        return temp;
    }

    public void setTemp(int temp) {
        this.temp = temp;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getDaytime() {
        return daytime;
    }

    public void setDaytime(String daytime) {
        this.daytime = daytime;
    }
}
