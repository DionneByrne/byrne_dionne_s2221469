
//
// Name                 Dionne Jayne Byrne
// Student ID           s2221469
// Programme of Study   Bsc (Hons) Computing
//

package com.example.byrne_dionne_s2221469;

public class WeatherForecast {
    private String title;
    private String link;
    private String description;
    private String update;
    private int minTemp;
    private int maxTemp;
    private String classification;
    private String dayOfWeek;

public WeatherForecast(){
    title = "";
    link = "";
    description = "";
    update = "";
    minTemp = 0;
    maxTemp = 0;
    classification = "";
    dayOfWeek = "";
}
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {

        try {
            this.title = title;

            //extracting minTemp, maxTemp, classification, day of Week
            //Thursday: Light Rain Showers, Minimum Temperature: 1°C (35°F) Maximum Temperature: 11°C (51°F)

            String dow = title.substring(0, title.indexOf(':'));
            this.dayOfWeek = dow;

            String clsfn = title.substring(title.indexOf(':') + 1, title.indexOf(',')).trim();
            this.classification = clsfn;

            if (title.indexOf("Minimum Temperature: ") > 0) {
                String mintmp = title.substring(title.indexOf("Minimum Temperature: ") + 21, title.indexOf('°')).trim();
                this.minTemp = Integer.parseInt(mintmp);
            }

            if (title.indexOf("Maximum Temperature: ") > 0) {
                String maxtmp = title.substring(title.indexOf("Maximum Temperature: ") + 21, title.indexOf('°', title.indexOf("Maximum Temperature: ") + 21)).trim();
                this.maxTemp = Integer.parseInt(maxtmp);
            }

        } catch (Exception e) {

        }
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUpdate() {
        return update;
    }

    public void setUpdate(String update) {
        this.update = update;
    }

    public int getMinTemp() {
        return minTemp;
    }

    public void setMinTemp(int minTemp) {
        this.minTemp = minTemp;
    }

    public int getMaxTemp() {
        return maxTemp;
    }

    public void setMaxTemp(int maxTemp) {
        this.maxTemp = maxTemp;
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        this.classification = classification;
    }

    public String getDayOfWeek() {
        return dayOfWeek;
    }

    public void setDayOfWeek(String dayOfWeek) {
        this.dayOfWeek = dayOfWeek;
    }
}
