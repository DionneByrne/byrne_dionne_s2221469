
//
// Name                 Dionne Jayne Byrne
// Student ID           s2221469
// Programme of Study   Bsc (Hons) Computing
//

package com.example.byrne_dionne_s2221469;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class WeatherAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<WeatherForecast> weatherForecasts;

    public WeatherAdapter(Context context, ArrayList<WeatherForecast> WeatherForecast) {
        this.context = context;
        this.weatherForecasts = WeatherForecast;
    }

    @Override
    public int getCount() {
        return weatherForecasts.size();
    }

    @Override
    public Object getItem(int position) {
        return position;
    }

    @Override
    public long getItemId(int position) {
        return position;
    }
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        convertView = LayoutInflater.from(this.context).inflate(R.layout.weather_list_view_layout, parent, false);

        WeatherForecast wf = this.weatherForecasts.get(position);

        TextView txtWeatherDow = convertView.findViewById(R.id.weatherDow);
        TextView txtWeatherClass = convertView.findViewById(R.id.weatherClass);
        TextView txtWeatherMinTemp = convertView.findViewById(R.id.weatherMinTemp);
        TextView txtWeatherMaxTemp = convertView.findViewById(R.id.weatherMaxTemp);
        ImageView iconImageView = convertView.findViewById(R.id.weatherIcon);
//Weather Icons
        int weatherValue = R.drawable.day_clear;
        if(wf.getClassification().contains("Sunny")) {
            weatherValue = R.drawable.day_clear;
        }
        else if(wf.getClassification().contains("Cloudy")) {
            weatherValue = R.drawable.cloudy;
        }
        else if(wf.getClassification().contains("Rain")) {
            weatherValue = R.drawable.rain;
        }
        else if(wf.getClassification().contains("Night")) {
            weatherValue = R.drawable.night_clear;
        }
        else if(wf.getClassification().contains("Thunder Rain")) {
            weatherValue = R.drawable.rain_thunder;
        }
        else if(wf.getClassification().contains("Partially Cloudy")) {
            weatherValue = R.drawable.day_partial_cloud;
        }
        else if(wf.getClassification().contains("Snow")) {
            weatherValue = R.drawable.snow;
        }
        else if(wf.getClassification().contains("Fog")) {
            weatherValue = R.drawable.fog;
        }
        else if(wf.getClassification().contains("Tornado")) {
            weatherValue = R.drawable.tornado;
        }
        else if(wf.getClassification().contains("Thunder")) {
            weatherValue = R.drawable.thunder;
        }
        else if(wf.getClassification().contains("Windy")) {
            weatherValue = R.drawable.wind;
        }
        else if(wf.getClassification().contains("Sleet")) {
            weatherValue = R.drawable.sleet;
        }

        txtWeatherDow.setText(wf.getDayOfWeek());
        txtWeatherClass.setText(wf.getClassification());
        txtWeatherMinTemp.setText(Integer.toString(wf.getMinTemp()) + "°C");
        if(wf.getMaxTemp() != 0) txtWeatherMaxTemp.setText(Integer.toString(wf.getMaxTemp()) + "°C");
        iconImageView.setImageResource(weatherValue);

        return convertView;
    }
}