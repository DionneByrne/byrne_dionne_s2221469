//
// Name                 Dionne Jayne Byrne
// Student ID           s2221469
// Programme of Study   Bsc (Hons) Computing
//

package com.example.byrne_dionne_s2221469;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.ImageFormat;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements OnClickListener
{
    private Spinner spinner;
    private ListView lstView;
    private Handler mHandler;
    private String urlForecast = "https://weather-broker-cdn.api.bbci.co.uk/en/forecast/rss/3day/";
    private String urlCurrent = "https://weather-broker-cdn.api.bbci.co.uk/en/observation/rss/";
    private String[] citiesArray = {
            // String array for the 6 locations
            "2648579", //glasgow
            "2643743", //london
            "5128581", //new york
            "287286", //oman
            "934154", //mauritius
            "1185241" //bangladesh
    };
    private ArrayList<WeatherForecast> weatherForecasts;
    private WeatherCurrent currentWeather;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        spinner = (Spinner) findViewById(R.id.spinner);
        // this is the ArrayAdapter
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.cities_array,
                android.R.layout.simple_spinner_item
        );
        lstView = (ListView) findViewById(R.id.list_view);
// drop down menu
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Spinner adapter
        spinner.setAdapter(adapter);

      weatherForecasts = new ArrayList<>();
      currentWeather = new WeatherCurrent();

      TextView studentNumberLabel = findViewById(R.id.studentNumberLabel);
      String studentNumber = "s2221469";
        studentNumberLabel.setText("Student Number: " + studentNumber);


        //toggle refresh
        this.mHandler = new Handler();

        this.mHandler.postDelayed(m_Runnable,5000);

    }

    public void onClick(View aview) {

    }

    private int getCityValue(String cityname) {
        int cityvalue = 0;

        switch(cityname){
            case "Glasgow":
                cityvalue = 0;
                break;
            case "London":
                cityvalue = 1;
                break;
            case "New York":
                cityvalue = 2;
                break;
            case "Oman":
                cityvalue = 3;
                break;
            case "Mauritius":
                cityvalue = 4;
                break;
            case "Bangladesh":
                cityvalue = 5;
                break;

        }
        return cityvalue;
    }

    public void currentWeatherButton_OnClick(View aview) {

        TextView textView = (TextView)spinner.getSelectedView();
        String result = textView.getText().toString();

        int cityvalue = getCityValue(result);
        String url = urlCurrent + citiesArray[cityvalue];

        startProgress(url, false);
    }


    public void forecastButton_OnClick(View aview)
    {
        TextView textView = (TextView)spinner.getSelectedView();
        String result = textView.getText().toString();

        int cityvalue = getCityValue(result);
        String url = urlForecast + citiesArray[cityvalue];

        startProgress(url, true);
    }

    public void startProgress(String url, boolean isForecast)
    {
        Log.e("Locations",url);

        new Thread(new Task(url, isForecast)).start();
    }

    private final Runnable m_Runnable = new Runnable()
    {
        public void run()
        {
            Toast.makeText(getBaseContext(), "Commencing Refresh", Toast.LENGTH_SHORT).show();

            forecastButton_OnClick(findViewById(R.id.forecastButton));
            currentWeatherButton_OnClick(findViewById(R.id.currentWeatherButton));

            mHandler.postDelayed(m_Runnable,60000);
        }

    };


    private class Task implements Runnable
    {
        private String url;
        private boolean isForecast;

        public Task(String aurl, boolean aisForecast)
        {
            url = aurl;
            isForecast = aisForecast;
        }


        @Override
        public void run()
        {

            URL aurl;
            URLConnection yc;
            BufferedReader in = null;
            String inputLine = "";
            String result = "";



            try
            {
                aurl = new URL(url);
                yc = aurl.openConnection();
                in = new BufferedReader(new InputStreamReader(yc.getInputStream()));
                while ((inputLine = in.readLine()) != null)
                {
                    result = result + inputLine;

                }
                in.close();
            }
            catch (IOException ae)
            {
                Log.e("MyTag", "ioexception");
            }

            int i = result.indexOf(">");
            result = result.substring(i+1);



            ParseXML(result, isForecast);


            MainActivity.this.runOnUiThread(new Runnable()
            {
                public void run() {
                    Log.d("UI thread", "I am the UI thread");

                    if(isForecast) {
                        WeatherAdapter forecastAdapter = new WeatherAdapter(getBaseContext(), weatherForecasts);
                        lstView.setAdapter(forecastAdapter);
                        forecastAdapter.notifyDataSetChanged();
                    } else {
                        //update textviews
                        TextView daytimeTxt = (TextView) findViewById(R.id.currentDayTxt);
                        TextView classificationTxt = (TextView) findViewById(R.id.currentClassTxt);
                        TextView tempTxt = (TextView) findViewById(R.id.currentTempTxt);

                        daytimeTxt.setText("Date & Time: " + currentWeather.getDaytime());
                        classificationTxt.setText("Weather: " + currentWeather.getClassification());
                        tempTxt.setText("Temperature: " + Integer.toString(currentWeather.getTemp()) + "°C");

                    }
                }
            });
        }

    }

    private void ParseXML(String result, boolean isForecast){
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            factory.setNamespaceAware(true);

            XmlPullParser xpp = factory.newPullParser();
            xpp.setInput(new StringReader(result));

            int eventType = xpp.getEventType();

            if (isForecast) {
                weatherForecasts = new ArrayList<>();
            }

            WeatherForecast wf = new WeatherForecast();
            WeatherCurrent wc = new WeatherCurrent();

            while (eventType != XmlPullParser.END_DOCUMENT) {

                if (eventType == XmlPullParser.START_TAG) {
                    String tag = xpp.getName().toLowerCase();

                    if (tag.equals("item")) {
                        wf = new WeatherForecast();
                        wc = new WeatherCurrent();
                    } else if (tag.equals("title")) {
                        if(isForecast) wf.setTitle(xpp.nextText());
                        if(!isForecast) wc.setTitle(xpp.nextText());
                    } else if (tag.equals("link")) {
                        if(isForecast) wf.setLink(xpp.nextText());
                        if(!isForecast) wc.setLink(xpp.nextText());
                    } else if (tag.equals("description")) {
                        if(isForecast) wf.setDescription(xpp.nextText());
                        if(!isForecast) wc.setDescription(xpp.nextText());
                    } else if (tag.equals("pubDate")) {
                        if(isForecast) wf.setUpdate(xpp.nextText());
                        if(!isForecast) wc.setPubdate(xpp.nextText());
                    }

                } else if (eventType == XmlPullParser.END_TAG) {
                    if (xpp.getName().equals("item") && isForecast) {
                        weatherForecasts.add(wf);
                    } else if (xpp.getName().equals("item") && !isForecast) {
                        currentWeather = wc;
                    }
                }
                eventType = xpp.next();

            }
        } catch (Exception e) {

        }
    }
}